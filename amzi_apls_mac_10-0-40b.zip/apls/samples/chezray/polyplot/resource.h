//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     101
#define IDD_STATUSWIN                   300
#define IDC_SCALE75                     1000
#define IDC_SCALE150                    1001
#define IDC_SCALE300                    1002
#define IDC_SCALE600                    1003
#define IDC_SCALE1200                   1004
#define IDC_SCALE2400                   1005
#define IDC_EDITX                       1023
#define IDC_EDITY                       1024
#define IDC_AXES                        1034
#define IDC_UNITC                       1035
#define IDC_SPIN1                       1036
#define IDC_SPIN2                       1037
#define IDC_TEXT                        1038
#define IDC_INV                         1039
#define IDC_BILINEAR                    1040
#define IDC_MAXIFLAT                    1041
#define IDC_Z7                          1042
#define IDC_SCALE1                      1043
#define IDC_SCALE2                      1044
#define IDC_SCALE3                      1045
#define IDC_ANGLE15                     1048
#define IDC_ANGLE30                     1049
#define IDC_ANGLE45                     1050
#define IDC_ANGLES                      1051
#define IDC_SOUND                       1052
#define IDC_SCALE                       -1
#define IDC_SCALE4                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
