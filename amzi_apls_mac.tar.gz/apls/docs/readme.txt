IMPORTANT

If you have a current version of Amzi! Prolog + Logic Server
on your machine either:

Uninstall it
  or
Install the new version in a different directory.

